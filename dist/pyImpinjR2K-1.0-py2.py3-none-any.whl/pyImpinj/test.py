# !/usr/bin/python
# -*- coding:utf-8 -*-
""" Test script."""
# Python:   3.6.5+
# Platform: Windows/Linux/MacOS
# Author:   Heyn (heyunhuan@gmail.com)
# Program:  Test script.
# Package:  None.
# Drivers:  None.
# History:  2020-02-20 Ver:1.0 [Heyn] Initialization

